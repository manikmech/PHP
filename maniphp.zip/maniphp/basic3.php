<?php
$a=4;
$b=6;
$c=6.5;
$d=4;
$d="hello world";
echo "<br>let c about the type of datas in the given values..";

echo "<br> <br>first value:".var_dump($a);
echo "<br>second value :".var_dump($b);
echo "<br> theird value :".var_dump($c);
echo "<br><br> let doo Arithmation operators";
echo "<br><br>addition:".($a+$b);
echo "<br>subtraction:".($a-$b);
echo "<br>Multiplication:".($a*$b);
echo "<br>Division:".($a/$b);
echo "<br>modular:".($a%$b);
echo "<br><br>assignment operator";
echo "<br><br>a==d is:".($a==$d);
echo "<br>a+=b is:".($a+=$b);
echo "<br>a-=b is:".($a-=$b);
echo "<br><br>increment or decrement operator";
echo "<br><br> ++a is:".(++$a);
echo "<br>--a is:".(--$b);
echo "<br>a++ is:".($a++)."  ".$a;
echo "<br> a-- is :".($a--). "  ".$a;

echo "<br><br>comparison operator";
echo "<br><br>a>b is:".($a>$b);
echo "<br>a<b is:".($a<$b);
echo "<br>a>=b is:".($a>=$b);
echo "<br>a!=b is:".($a!=$b);
echo "<br>a==b is:".($a==$b);
echo "<br>a===b is:".($a===$b);
echo "<br>a===b is:".($a===$c);

?>