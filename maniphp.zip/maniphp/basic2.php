<?php
$a="hello world";

$b="im good  im loooking towards my great appearence, i dont how to be succeed in life.";
$c=6;
echo strlen($a);
echo "<br>".str_word_count($a);
echo "<br>tells about number of characters in this variable=".strlen($b);
echo"<br> tells number of words in this=".str_word_count("im loooking towards my great appearence,");
echo "<br> perfect reverse==".strrev($b);
echo "<br> string position==".strpos("$b","great");
echo "<br> string replace==".str_replace("life.","world",$b);
define("mani",$b);
echo "<br>".mani;
?>