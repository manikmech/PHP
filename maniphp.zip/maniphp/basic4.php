<?php

$a=1000;
$b=2000;
$c=4000;
$e=5;

echo "<br>if condition";
echo "<br>";
if($a>$b)
{

	echo"<br> a is greater value";
}
else
{
	echo"<br> b is greater  value";
}
echo "<br><br>";
echo "<br>ifelseif condition";
echo "<br>";
if($a<=1000)

{

	echo"<br> a is less than 1000 ";
}
elseif($a<=2000)
{
	echo"<br> a is less  than 2000";
}
elseif($a<=3000)
{
	echo"<br> a is less than  value 3000";
}
else
{
	echo"<br> a is greater of all condition";
}
echo "<br><br>";
echo "<br>  switch condition";
echo "<br>";
switch($c)
{
case "1000":
 echo "1000 is entered";
break;
case "2000":
 echo "2000 is entered";
break;
case "3000":
 echo "3000 is entered";
break;
default: 
echo "entered above 3000";
}
echo "<br><br>";
echo "<br>  forloop";
echo "<br>";
for ($i=0; $i <$e ; $i++)
 { 

	echo "print the loop values:".$i++;
}

echo "<br><br>";
echo "<br>  whileloop";
echo "<br>";
while ( $e<= 10) {
	echo "<br>print the loop values:".$e;
$e++;
}
echo "<br><br>";
echo "<br>  dowhileloop";
echo "<br>";
$e=5;
do {
	echo "<br>print the loop values:".$e;
$e++;
}
while ( $e<= 10);
echo "<br><br>";
echo "<br>  foreach loop";
echo "<br>";
$cars=array("valvo","shift","scoda","hyundai","toyoto","bentz","audi");
foreach ($cars as  $value) 
{
echo"<br>".$value;
}
 

?>