<?php
$a="variable";
$b=3;
$c=5;
$d;
echo var_dump($a).var_dump($b).var_dump($c).var_dump($d);




?>